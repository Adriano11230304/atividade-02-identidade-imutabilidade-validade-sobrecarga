package TimeSpan;

class TimeSpan{
  final private int seconds;

  TimeSpan (int d, int h, int m, int s){
    if ((d == 0) && (h == 0) && (m == 0) && (s == 0)){
        throw new IllegalArgumentException ("Can't be zero;");
    }
    if (d < 0){
        throw new IllegalArgumentException ("Can't be negative;");
    }
    if (h < 0){
        throw new IllegalArgumentException ("Can't be negative;");
    }
    if (m < 0){
        throw new IllegalArgumentException ("Can't be negative;");
    }
    if (s < 0){
        throw new IllegalArgumentException ("Can't be negative;");
    }
    seconds = (d*86400)+(h*3600)+(m*60)+s;
  }
  TimeSpan (int h, int m, int s){
    seconds = (h*3600)+(m*60)+s;
  }

  int getDays(){
    int days;
    if (seconds >= 86400){
      days = seconds/86400;
      return days;
    }else{
      return 0;
    }
  }
  int getHours(){
    int hours = 0;
    if (seconds >= 86400){
      hours = seconds%86400;
      hours /= 3600;
      return hours;
  } else if (seconds >= 3600){
      hours = seconds/3600;
      return hours;
    } else{
      return 0;
    }
  }
  int getMinutes(){
    int m = seconds;
    if (m >= 86400){
      m %= 86400;
      m %= 3600;
      m /= 60;
      return m;
    } else if (m >= 3600){
      m %= 3600;
      m /= 60;
      return m;
    } else if (m >= 60){
      m /= 60;
      return m;
    } else{
      return 0;
    }
  }
  int getSeconds(){
    int s = 0;
    if (seconds >= 86400){
      s = seconds%86400;
      s %= 3600;
      s %= 60;
      return s;
    } else if (seconds >= 3600){
      s = seconds%3600;
      s %= 60;
      return s;
  } else if (seconds>=60){
      s = seconds % 60;
      return s;
  }else{
      s = seconds;
      return s;
  }
 }

    boolean greaterThan (TimeSpan t){
        return this.seconds > t.seconds;
    }
    boolean lessThan (TimeSpan t){
        return this.seconds < t.seconds;
    }

 @Override
 public String toString (){
    String d = ""; String h = ""; String m = ""; String s = "";
    if (this.getDays()>0) d += this.getDays()+" day";
    if (this.getDays()>1) d += "s";
    if (this.getHours()>0){
        if (this.getDays()>0){
                h += ", " + this.getHours() + " hour";
        }else{
            h += this.getHours() + " hour";
        }
    }
    if (this.getHours()>1) h += "s";
    if (this.getMinutes()>0){
        if (this.getHours()>0 || this.getDays()>0){
                m += ", " + this.getMinutes()+ " minute";
        }else{
            m += this.getMinutes() + " minute";
        }
    }
    if (this.getMinutes()>1) m += "s";
    if (this.getSeconds()>0){
        if (this.getDays()>0 || this.getHours()>0 || this.getMinutes()>0){
            s += " e " + this.getSeconds() + " second";
        }else{
            s += this.getSeconds() + " second";
        }
    }
    if (this.getSeconds()>1) s += "s";
    return d + h + m + s;
 }

     public String toString (String p){
         if (p.equals("pt")){
             String d = ""; String h = ""; String m = ""; String s = "";
             if (this.getDays()>0) d += this.getDays()+" dia";
             if (this.getDays()>1) d += "s";
             if (this.getHours()>0){
                 if (this.getDays()>0){
                         h += ", " + this.getHours() + " hora";
                 }else{
                     h += this.getHours() + " hora";
                 }
             }
             if (this.getHours()>1) h += "s";
             if (this.getMinutes()>0){
                 if (this.getHours()>0 || this.getDays()>0){
                         m += ", " + this.getMinutes()+ " minuto";
                 }else{
                     m += this.getMinutes() + " minuto";
                 }
             }
             if (this.getMinutes()>1) m += "s";
             if (this.getSeconds()>0){
                 if (this.getDays()>0 || this.getHours()>0 || this.getMinutes()>0){
                     s += " e " + this.getSeconds() + " segundo";
                 }else{
                     s += this.getSeconds() + " segundo";
                 }
             }
             if (this.getSeconds()>1) s += "s";
             return d + h + m + s;
         }else{
             return "";
         }

     }

     @Override
     public boolean equals(Object s){
         TimeSpan outro = (TimeSpan) s;
         return this.seconds == outro.seconds;
     }

}
