package Ponto;

class Ponto extends Time{
    private final String funcionario;
	private Time entrada;
	private Time saida;

    Ponto (String p){
        funcionario = p;
        this.entrada = new Time (0, 0, 0);
        this.saida = new Time (0, 0, 0);
    }
    
    void bater(int h, int m, int s) {
    	if (entrada.getHours() == 0 && entrada.getMinutes() == 0 && entrada.getSeconds()==0) {
    		this.entrada = new Time (h, m, s);
    	}else if (saida.getHours() == 0 && saida.getMinutes() == 0 && saida.getSeconds()==0){
    		this.saida = new Time (h, m, s);
    	} else {
    		throw new IllegalArgumentException ("Entrada e saída já foram batidos e o ponto está fechado");
    	}
    }

    @Override
    public String toString (){
    	String h = "" + entrada.getHours() + ":";
        String m = "" + entrada.getMinutes() + ":";
        String s = "" + entrada.getSeconds();
        if (entrada.getHours() < 10) h = "0" + h;
        if (entrada.getMinutes()<10) m = "0" + m;
        if (entrada.getSeconds()<10) s = "0" + s;
        String saidah = "" + saida.getHours() + ":";
        String saidam = "" + saida.getMinutes() + ":";
        String saidas = "" + saida.getSeconds();
        if (saida.getHours() < 10) saidah = "0" + saidah;
        if (saida.getMinutes()<10) saidam = "0" + saidam;
        if (saida.getSeconds()<10) saidas = "0" + saidas;
        int segundosEntrada = (entrada.getHours()*3600) + (entrada.getMinutes()*60)+entrada.getSeconds();
        int segundosSaida = (saida.getHours()*3600) + (saida.getMinutes()*60)+saida.getSeconds();
        if (segundosEntrada == 0){
        	return this.funcionario + " não bateu o ponto";
        } else if (segundosSaida == 0) {
        	return this.funcionario + " entrou às " + h + m + s;
        } else {
        	if (segundosSaida < segundosEntrada) {
        		segundosEntrada = (24*3600) - segundosEntrada; 
        		segundosSaida += segundosEntrada;
        	}else {
        		segundosSaida -= segundosEntrada;
        	}
        	if (segundosSaida < 0) segundosSaida *= -1;
        	String calculoHours = ""+(segundosSaida/3600);
        	String calculoMinutes = ""+((segundosSaida%3600)/60);
        	String calculoSeconds = ""+((segundosSaida%3600)%60);
        	String calculoTotal = "";
        	if (calculoHours.equals("0")) {
        		if (calculoMinutes.equals("0")) {
        			calculoTotal += calculoSeconds + " segundos";
        		}else {
        			calculoTotal += calculoMinutes + "minutos e "+ calculoSeconds + " segundos";
        		}
        	}else if (calculoMinutes.equals("0")) {
        		calculoTotal += calculoHours + " horas e "+calculoSeconds+" segundos";
        	}else if (calculoSeconds.equals("0")) {
        		calculoTotal += calculoHours + " horas e "+calculoMinutes+" minutos";
        	}else {
        		calculoTotal += calculoHours + " horas, "+calculoMinutes+" minutos e "+calculoSeconds+" segundos";
        	}
        	 
        	return this.funcionario + " entrou às " + h + m + s + " e saiu às " + saidah + saidam + saidas + " e permaneceu " + calculoTotal;
        }
    }
}
