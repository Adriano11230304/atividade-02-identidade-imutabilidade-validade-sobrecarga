package Ponto;

class Time{
    private final int seconds;

    Time (int h, int m, int s){
        while (h < 0){
            h = 24 + h;
        }
        while (m < 0){
            m += 60;
        }
        while (s < 0){
            s += 60;
        }
        s += (h*3600)+(m*60);
        /*
        while(s<0){
            s += 86400;
        }
        */
        while (s >= 86400){
            s -= 86400;
        }
        seconds = s;
    }
    Time (){
        seconds = 0;
    }
    Time (int h, int m){
        int s = (h*3600)+(m*60);
        seconds = s;
    }

    int getSeconds (){
        int s = seconds;
        if (s >= 3600){
            s %= 3600;
            return s %= 60;
        } else if (s >= 60){
            return s %= 60;
        } else{
            return s;
        }
    }
    int getMinutes (){
        int m = seconds;
        if (m >= 3600){
            m %= 3600;
            return m /= 60;
        }else if (m >= 60){
            return m /= 60;
        }
        return 0;
    }
    int getHours (){
        int h = seconds;
        if (h >= 3600){
            return h/= 3600;
            } else{
            return 0;
        }
    }

    Time plus (Time t){
        return new Time ((this.getHours()+t.getHours()),(this.getMinutes()+t.getMinutes()), (this.getSeconds()+t.getSeconds()));
    }
    Time plusHours (int h){
        return new Time (this.getHours() + h, this.getMinutes(), this.getSeconds());
    }
    Time plusMinutes(int m){
        return new Time (this.getHours(), this.getMinutes() + m, this.getSeconds());
    }
    Time plusSeconds (int s){
        return new Time (this.getHours(), this.getMinutes(), this.getSeconds()+s);
    }
    Time minusHours(int h){
        return new Time (this.getHours()-h, this.getMinutes(), this.getSeconds());
    }
    Time minusMinutes(int m){
        return new Time (this.getHours(), this.getMinutes()-m, this.getSeconds());
    }
    Time minusSeconds(int s){
        return new Time (this.getHours(), this.getMinutes(), this.getSeconds()-s);
    }
    Time minus (Time t){
        return new Time (this.getHours()-t.getHours(), this.getMinutes()-t.getMinutes(), this.getSeconds()-t.getSeconds());
    }

    boolean isMidDay (){
        return this.seconds == 43200;
    }
    boolean isMidNight(){
        return this.seconds == 0;
    }

    Time shift (){
        return new Time(this.getHours()+12, this.getMinutes(), this.getSeconds());
    }

    Time tick(){
        return new Time (this.getHours(), this.getMinutes(), this.getSeconds()+1);
    }
    
    @Override
    public boolean equals(Object t) {
        Time outro = (Time) t;
        return this.seconds == outro.seconds;
    }

    @Override
    public String toString() {
        String h = "" + this.getHours();
        String m = "" + this.getMinutes();
        String s = "" + this.getSeconds();
        if (this.getHours() < 10){
            h = "0" + h;
        }
        if (this.getMinutes() < 10){
            m = "0" + m;
        }
        if (this.getSeconds() < 10){
            s = "0" + s;
        }
        return h + ":" + m + ":" + s;
    }

}
