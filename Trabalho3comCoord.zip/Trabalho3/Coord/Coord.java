package Coord;

public class Coord {
	private final double latitude;
	private final double longitude;
	Coord (){
		this.latitude = 0.0;
		this.longitude = 0.0;
	}
	Coord (double latitude, double longitude){
		if (latitude <= 90 && latitude >= -90) {
			this.latitude = latitude;
		}else {
			throw new IllegalArgumentException("latitude errada, deve ser entre -90 e +90;");
		}
		if (longitude <= 180 && longitude >= -180) {
			this.longitude = longitude;
		}else {
			throw new IllegalArgumentException("longitude errada, deve ser entre -180 e +180;");
		}
	}
	
	double getLat() {
		return this.latitude;
	}
	double getLong() {
		return this.longitude;
	}
	Coord moveNorth (double lat) {
		return new Coord(this.getLat()+lat, this.getLong());
	}
	
	Coord moveSouth (double lat) {
		return new Coord(this.getLat()-lat, this.getLong());
	}
	
	Coord moveEast (double lon) {
		return new Coord(this.getLat(), this.getLong()+lon);
	}
	Coord moveWest (double lon) {
		return new Coord(this.getLat(), this.getLong()-lon);
	}
	
	boolean isEquatorLine () {
		return this.getLat() == 0;
	}
	boolean isMeridianLine () {
		boolean meridian = false;
		if (this.getLong()==0 || this.getLong()==180 || this.getLong()==-180) {
			meridian = true;
		}
		return meridian;
	}
	boolean isNorth() {
		return this.getLat() > 0;
	}
	boolean isSouth() {
		return this.getLat() < 0;
	}
	boolean isOrient() {
		return this.getLong() > 0;
	}
	boolean isOcident() {
		return this.getLong() < 0;
	}
	
	@Override
	public String toString () {
		return this.getLat()+"°, "+this.getLong()+"°";
	}
	
	@Override
	public boolean equals(Object t) {
		Coord Outro = (Coord) t;
		boolean eq = false;
		if (this.getLat()==Outro.getLat() && this.getLong()==Outro.getLong()) {
			eq = true;
		}
		return eq;
	}
}
